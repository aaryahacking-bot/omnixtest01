from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector
import smtplib
import random
from email.mime.text import MIMEText

app = Flask(__name__)

# --- CONFIGURATIONS ---
app.secret_key = 'omnix_secret_key_123' # Session ke liye zaroori hai

# 1. Database Connection
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",          
        password="mysql@123",  # <--- APNA SAHI MYSQL PASSWORD YAHAN CHECK KARLO
        database="OmnixDB"
    )

# 2. Email Configuration (Gmail OTP ke liye)
SENDER_EMAIL = "omnixofficials@gmail.com"  # <--- APNI GMAIL ID YAHAN DALO
APP_PASSWORD = "ledx jraz vtjj gnod"   # <--- WO 16-LETTER APP PASSWORD YAHAN DALO

# --- ROUTES ---

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/signup_page')
def signup_page():
    return render_template('signup.html')

@app.route('/forgot_page')
def forgot_page():
    return render_template('forgot.html')

# SIGNUP LOGIC
@app.route('/signup', methods=['POST'])
def signup():
    full_name = request.form.get('fullname')
    username = request.form.get('username')
    email = request.form.get('email')
    password = request.form.get('password')

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO users (full_name, username, email, password) VALUES (%s, %s, %s, %s)", 
                   (full_name, username, email, password))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for('index'))

# LOGIN LOGIC
@app.route('/login', methods=['POST'])
def login():
    user_id = request.form.get('user_id')
    password = request.form.get('password')

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE (username=%s OR email=%s) AND password=%s", 
                   (user_id, user_id, password))
    user = cursor.fetchone()
    cursor.close()
    conn.close()

    if user:
        session['user_name'] = user['full_name']
        return redirect(url_for('home'))
    else:
        return render_template('index.html', error="Invalid Username or Password!")

# FORGOT PASSWORD - SEND OTP LOGIC
@app.route('/send_otp', methods=['POST'])
def send_otp():
    email = request.form.get('email')
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE email=%s", (email,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    
    if user:
        # Generate 6-digit OTP
        otp = str(random.randint(100000, 999999))
        session['reset_otp'] = otp
        session['reset_email'] = email
        
        # Email Bhejne ka Code
        try:
            msg = MIMEText(f"Hello, Your Omnix Password Reset OTP is: {otp}")
            msg['Subject'] = 'Omnix Password Recovery'
            msg['From'] = SENDER_EMAIL
            msg['To'] = email
            
            with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
                server.login(SENDER_EMAIL, APP_PASSWORD)
                server.sendmail(SENDER_EMAIL, email, msg.as_string())
            
            return render_template('verify_otp.html')
        except Exception as e:
            print(e)
            return render_template('forgot.html', error="Email service error. Try again later.")
    else:
        return render_template('forgot.html', error="This email is not registered with Omnix!")

# OTP VERIFICATION LOGIC
@app.route('/verify_otp', methods=['POST'])
def verify_otp():
    user_otp = request.form.get('user_otp')
    if user_otp == session.get('reset_otp'):
        # Agar OTP sahi hai, toh naya password banane wala page dikhao
        return render_template('reset_password.html')
    else:
        return "<h1>Wrong OTP!</h1><p>Please check your email again and go back.</p>"

# UPDATE PASSWORD LOGIC (Database mein naya password save karna)
@app.route('/update_password', methods=['POST'])
def update_password():
    new_password = request.form.get('new_password')
    email = session.get('reset_email') # Jis email ka OTP verify hua tha

    if email and new_password:
        conn = get_db_connection()
        cursor = conn.cursor()
        # Naya password set karo jahan email match ho
        cursor.execute("UPDATE users SET password=%s WHERE email=%s", (new_password, email))
        conn.commit()
        cursor.close()
        conn.close()

        # Security ke liye session se OTP hata do
        session.pop('reset_otp', None)
        session.pop('reset_email', None)

        # Password change hone ke baad seedha Login page par bhejo
        return redirect(url_for('index'))
    else:
        return "Session expired! Please try the Forgot Password process again."

@app.route('/home')
def home():
    if 'user_name' in session:
        return render_template('home.html', name=session['user_name'])
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)